package com.cg.trainingmanagementsystem.dao;

public interface TrainerManagementDao {

}
