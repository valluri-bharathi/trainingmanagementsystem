package com.cg.trainingmanagementsystem.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import com.cg.trainingmanagementsystem.dao.ICrudOperation;
import com.cg.trainingmanagementsystem.dao.TrainerManagementDao;
import com.cg.trainingmanagementystem.exception.InvalidDetailsException;
import com.cg.trainingmanagementystem.service.entity.Employee;
import com.cg.trainingmanagementystem.service.entity.Trainer;
import com.cg.trainingmanagementystem.utility.ConnectionDb;
import com.cg.trainingmanagementystem.utility.ProgramExceptions;
import com.cg.trainingmanagementystem.utility.Query;

public class TrainerManagementDaoImpl implements ICrudOperation<Trainer>, TrainerManagementDao {
//To get trainer details from database
	@Override
	public Set<Employee> retrieveAll() {
		//STEP 1:establishing connection
		Connection connection = ConnectionDb.getConnection();
		String sql = Query.GET_EMPLOYEE_DETAILS_THROUGH_EMPID;
		Set<Employee> employees = new HashSet<Employee>();
		try {
			//step 2:create a statement
			PreparedStatement preparedStatement = connection.prepareStatement(sql);
			//step 3:execute statement and return query
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				Employee employee = new Employee();
				employee.setEmployeeId(rs.getString(1));
				employee.setEmployeeName(rs.getString(2));
				employees.add(employee);
			}
			// step 4:closing
			rs.close();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return employees;
	}
//To create a trainer
@Override
	public boolean create(String employeeId,String employeeName,String roleId) throws InvalidDetailsException{
		boolean result=false;
		//STEP 1:establishing connection
    Connection connection = ConnectionDb.getConnection();
    String sql = Query.CREATE_EMPLOYEE;
    Set<Employee> employees = new HashSet<Employee>();
		try {
			//step 2:create a statement
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setString(1,employeeId);
			statement.setString(2,employeeName);
			statement.setString(3,roleId);
			//step 3:execute statement and return query
			int i=statement.executeUpdate();
	// step 4:closing
			if(i==1) {
				result=true;
			}
			statement.close();
}
		catch(SQLException e) {
			
			throw new InvalidDetailsException(ProgramExceptions.message1);
		}
	return result;
	}
	@Override
	public boolean update(Trainer o) {
		return false;
	}
@Override
	public Trainer retrieve(Trainer o) {
		return null;
	}
@Override
	public boolean delete(Trainer o) {
		return false;
	}
}