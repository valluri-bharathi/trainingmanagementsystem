package com.cg.trainingmanagementsystem.dao;
import java.sql.SQLException;
import java.util.*;

import com.cg.trainingmanagementystem.exception.InvalidDetailsException;
import com.cg.trainingmanagementystem.service.entity.Employee;
public interface ICrudOperation<T> {
public boolean update(T o);
public T retrieve(T o);
public boolean delete(T o);
public Set<Employee> retrieveAll() throws SQLException;
public boolean create(String employeeId,String employeeName,String roleId) throws SQLException, InvalidDetailsException;
	

}