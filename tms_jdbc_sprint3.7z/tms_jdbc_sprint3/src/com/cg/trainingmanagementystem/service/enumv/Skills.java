package com.cg.trainingmanagementystem.service.enumv;

public enum Skills {
	C,JAVA,CSHARP,PYTHON

}
