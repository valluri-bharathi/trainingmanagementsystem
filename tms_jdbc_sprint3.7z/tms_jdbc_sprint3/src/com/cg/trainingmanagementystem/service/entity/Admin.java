package com.cg.trainingmanagementystem.service.entity;

public class Admin extends Employee {

	/**
	 * Default constructor
	 */
	public Admin() {
		
	}

}