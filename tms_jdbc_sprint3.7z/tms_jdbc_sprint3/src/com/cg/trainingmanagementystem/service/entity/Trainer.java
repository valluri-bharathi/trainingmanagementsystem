package com.cg.trainingmanagementystem.service.entity;


import java.util.Set;

import com.cg.trainingmanagementystem.service.enumv.Skills;

public class Trainer {
private String trainerName;
private String trainerAddress;
private Set<Skills> skills;
public Trainer(String trainerId, String trainerName, String trainerAddress, Set<Skills> skills) {
		super();
		this.trainerId = trainerId;
		this.trainerName = trainerName;
		this.trainerAddress = trainerAddress;
		this.skills = skills;
	}

	

	public Trainer() {
	// TODO Auto-generated constructor stub
}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((skills == null) ? 0 : skills.hashCode());
		result = prime * result + ((trainerAddress == null) ? 0 : trainerAddress.hashCode());
		result = prime * result + ((trainerId == null) ? 0 : trainerId.hashCode());
		result = prime * result + ((trainerName == null) ? 0 : trainerName.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Trainer other = (Trainer) obj;
		if (skills == null) {
			if (other.skills != null)
				return false;
		} else if (!skills.equals(other.skills))
			return false;
		if (trainerAddress == null) {
			if (other.trainerAddress != null)
				return false;
		} else if (!trainerAddress.equals(other.trainerAddress))
			return false;
		if (trainerId == null) {
			if (other.trainerId != null)
				return false;
		} else if (!trainerId.equals(other.trainerId))
			return false;
		if (trainerName == null) {
			if (other.trainerName != null)
				return false;
		} else if (!trainerName.equals(other.trainerName))
			return false;
		return true;
	}



	@Override
	public String toString() {
		return " trainerName=" + trainerName + ", trainerAddress=" + trainerAddress + ", skills=" + skills
				+ ", trainerId=" + trainerId + " ";
	}
private String trainerId;
public String getTrainerId() {
		return trainerId;
	}

	public void setTrainerId(String trainerId) {
		this.trainerId = trainerId;
	}

	public String getTrainerName() {
		return trainerName;
	}

	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}

	public String getTrainerAddress() {
		return trainerAddress;
	}

	public void setTrainerAddress(String trainerAddress) {
		trainerAddress = trainerAddress;
	}

	public Set<Skills> getSkills() {
		return skills;
	}

	public void setSkills(Set<Skills> skills) {
		this.skills = skills;
	}

	

	


}