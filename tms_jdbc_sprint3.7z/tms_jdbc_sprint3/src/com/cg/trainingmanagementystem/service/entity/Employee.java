package com.cg.trainingmanagementystem.service.entity;

public class Employee {
	private String employeeName;
	private String employeeId;
	private String roleId;

	public Employee() {
	}

	public String getEmployeeName(String employeeName) {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	@Override
	public String toString() {
		return "Employee: [EmployeeName= " + employeeName + ", TrainerId=" + employeeId + "]";
	}
}