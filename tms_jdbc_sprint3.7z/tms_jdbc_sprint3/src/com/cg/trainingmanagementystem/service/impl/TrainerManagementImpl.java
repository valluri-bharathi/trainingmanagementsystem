package com.cg.trainingmanagementystem.service.impl;

import java.sql.SQLException;
import java.util.Set;
import com.cg.trainingmanagementsystem.dao.ICrudOperation;
import com.cg.trainingmanagementsystem.dao.impl.TrainerManagementDaoImpl;
import com.cg.trainingmanagementystem.exception.InvalidDetailsException;
import com.cg.trainingmanagementystem.service.ITrainerManagement;
import com.cg.trainingmanagementystem.service.entity.Employee;
import com.cg.trainingmanagementystem.service.enumv.Skills;
import com.cg.trainingmanagementystem.utility.EmployeeDetailsValidation;
public class TrainerManagementImpl implements ITrainerManagement {
@Override
	public boolean addSkillsToTrainer(String trainerId, Set<String> skill) {
		return false;
	}
@Override
	public boolean delSkillsToTrainer(String trainerId, Skills skills) {
		return false;
	}
//To get all trainer details from employee table
	@Override
	public Set<Employee> getAllTrainers() throws SQLException {
		ICrudOperation tmd = new TrainerManagementDaoImpl();
		Set<Employee> employee = tmd.retrieveAll();
		return employee;
	}
//To create a employee
	@Override
	public boolean createTrainer(String employeeId,String employeeName,String roleId) throws SQLException, InvalidDetailsException {
		boolean result=false;
		ICrudOperation crudOperation=new TrainerManagementDaoImpl();
		EmployeeDetailsValidation detailsValidation=new EmployeeDetailsValidation();
		if(detailsValidation.isEmployeeNameValidate(employeeName)&& detailsValidation.isRoleIdValidate(roleId)){
			 result = crudOperation.create(employeeId,employeeName,roleId);
			}
		return result ;
	}
}
