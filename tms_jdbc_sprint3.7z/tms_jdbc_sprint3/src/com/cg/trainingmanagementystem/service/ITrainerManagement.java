package com.cg.trainingmanagementystem.service;

import java.sql.SQLException;
import java.util.*;

import com.cg.trainingmanagementystem.exception.InvalidDetailsException;
import com.cg.trainingmanagementystem.service.entity.Employee;
import com.cg.trainingmanagementystem.service.enumv.Skills;
public interface ITrainerManagement {
public boolean addSkillsToTrainer( String trainerId,Set<String> skill);
public boolean delSkillsToTrainer( String trainerId, Skills skills);
public Set<Employee> getAllTrainers() throws SQLException;
public boolean createTrainer(String employeeId,String employeeName,String roleId) throws SQLException, InvalidDetailsException;
}
	
	
	
	
	

	

