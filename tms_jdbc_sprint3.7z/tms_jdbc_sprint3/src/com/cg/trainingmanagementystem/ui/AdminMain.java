package com.cg.trainingmanagementystem.ui;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import com.cg.trainingmanagementystem.exception.InvalidDetailsException;
import com.cg.trainingmanagementystem.service.ITrainerManagement;
import com.cg.trainingmanagementystem.service.entity.Employee;
import com.cg.trainingmanagementystem.service.impl.TrainerManagementImpl;
import com.cg.trainingmanagementystem.utility.EmployeeDetailsValidation;

public class AdminMain {
	public static void main(String[] args) throws InvalidDetailsException {
do {
		int choice;
		try {
			Scanner scanner = new Scanner(System.in);
			System.out.println("---------WELCOME TO TRAINING MANAGEMENT SYSTEM-----");
			System.out.println("------------------");
			System.out.println("-----------WELCOME TO ADMIN OPERATION--------");
			System.out.println("1.GET ALL TRAINERS DETAILS");
			System.out.println("2.CREATE TRAINER");
			System.out.println("3.EXIT");
			System.out.println("ENTER YOUR CHOICE");
			choice =scanner.nextInt();
			TrainerManagementImpl impl = new TrainerManagementImpl();
			switch (choice) {
			case 1:
				ITrainerManagement iTrainerManagement = new TrainerManagementImpl();
				Set<Employee> tt = iTrainerManagement.getAllTrainers();
				Iterator<Employee> employee = tt.iterator();
				while (employee.hasNext()) {
					System.out.println(employee.next());
				}
				break;
			case 2:
                System.out.println("------TO CREATE A EMPLOYEE------");
				System.out.println("ENTER THE EMPLOYEE ID");
				EmployeeDetailsValidation detailsValidation = new EmployeeDetailsValidation();
				String employeeId = scanner.next();
				System.out.println("ENTER THE EMPLOYEE NAME");
				String employeeName = scanner.next();
				System.out.println("ENTER THE ROLE ID");
				String roleId = scanner.next();
                if (!detailsValidation.isEmployeeIdValidate(employeeId)) {
					throw new InvalidDetailsException("invalid employeeId..please enter a valid ID");
				}
				boolean result = impl.createTrainer(employeeId,employeeName,roleId);
				if(result==true) {
					System.out.println("data got added");

				}
				
			case 3:
				System.exit(0);
			default:
				break;
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		
	}

while(true);
}
}
