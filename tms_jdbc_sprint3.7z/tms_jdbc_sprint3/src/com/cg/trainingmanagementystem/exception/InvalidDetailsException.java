package com.cg.trainingmanagementystem.exception;

public class InvalidDetailsException extends Exception {
	public InvalidDetailsException(String message) {
		super(message);
	}
	

}
