package com.cg.trainingmanagementystem.utility;

public class Query {
	 public static final String  GET_EMPLOYEE_DETAILS_THROUGH_EMPID= "select employee.roleId,employee.employeeName from employee inner join role on employee.roleId=role.roleId and role.role_DESC='trainer'";
	public static final String CREATE_EMPLOYEE="insert into employee(employeeId,employeeName,roleId) values(?,?,?)";
}
