package com.cg.trainingmanagementystem.utility;

import com.cg.trainingmanagementystem.exception.InvalidDetailsException;

public class EmployeeDetailsValidation {
	public boolean isEmployeeIdValidate(String employeeId)throws InvalidDetailsException {
		
		if(employeeId.matches("EM_[0-9]{4}"))
				{
		          return true;
				}
		          else {
		        	  throw new InvalidDetailsException("PLEASE ENTER A VALID EMPLOYEE ID");
		          }
			
		}
		
	
	public boolean isEmployeeNameValidate(String employeeName )throws InvalidDetailsException {
		
		if(employeeName.matches("[a-zA-Z]{3,15}"))
				{
			      return true;
		         
				}
		else {
			throw new InvalidDetailsException("PLEASE ENTER A VALID EMPLOYEE NAME");
		}
		
			
		
	}
		public boolean isRoleIdValidate(String roleId )throws InvalidDetailsException {
			
			if(roleId.matches("RT_1001"))
					{
			          return true;
					}
			else {
	        	  throw new InvalidDetailsException("PLEASE ENTER A VALID ROLE ID");
	          }
			
		
				
			
		}
}
		
		
		
	


