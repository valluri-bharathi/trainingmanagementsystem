package com.cg.trainingmanagementystem.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConnectionDb {
	static Connection connection=null;
	public static Connection getConnection() {
		if(connection==null) {
			try {
				connection=DriverManager.getConnection("jdbc:oracle:thin:@10.236.246.29:1521:xe","sys as sysdba","system");
			}
			catch(SQLException ex) {
				throw new RuntimeException("error connecting to the databse",ex);
			}
		}
		return connection;
	}

}
