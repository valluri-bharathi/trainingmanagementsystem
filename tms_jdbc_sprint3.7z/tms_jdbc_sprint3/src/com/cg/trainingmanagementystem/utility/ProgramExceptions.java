package com.cg.trainingmanagementystem.utility;

public class ProgramExceptions {
	
	public static final String message1 = "ENTERED EMPLOYEE ID ALREADY EXISTS IN THE DATA BASE";
	
	
	

}
