package com.cg.trainingmanagementystem.utility;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import com.cg.trainingmanagementystem.exception.InvalidDetailsException;

	public class EmployeeDetailsValidationTest {
		EmployeeDetailsValidation employeeDetailsValidation=new EmployeeDetailsValidation();
	       @Test
			public  void employeeNameValidate() throws InvalidDetailsException {
				boolean string=employeeDetailsValidation.isEmployeeNameValidate("amit");
				assertEquals(true,string);
			}
	       @Test(expected = InvalidDetailsException.class)
	       public void  employeeNameEmptyValidate() throws InvalidDetailsException{
	    	   boolean b=employeeDetailsValidation.isEmployeeNameValidate("");
	    	   assertEquals(true, b);
	       }
	       @Test(expected = InvalidDetailsException.class)
	       public void employeeNameNumeric() throws InvalidDetailsException{
	    	   boolean bool=employeeDetailsValidation.isEmployeeNameValidate("58589");
	    	   assertEquals(true, bool);
	       }
	       @Test(expected = InvalidDetailsException.class)
	       
	       public void  employeeNameSpecialCharacter() throws InvalidDetailsException{
	    	   boolean a=employeeDetailsValidation.isEmployeeNameValidate("sam@");
	    	   assertEquals(true, a);
	       }
	       @Test
			public  void employeeIdValidate() throws InvalidDetailsException {
				boolean string=employeeDetailsValidation.isEmployeeIdValidate("EM_1007");
				assertEquals(true,string);
	       }
	       @Test(expected = InvalidDetailsException.class)
			public  void employeeIdEmptyValidate() throws InvalidDetailsException {
				boolean string=employeeDetailsValidation.isEmployeeIdValidate("");
				assertEquals(true,string);
	       }
	       @Test(expected = InvalidDetailsException.class)
			public  void employeeIdSpecialCharacterValidate() throws InvalidDetailsException {
				boolean string=employeeDetailsValidation.isEmployeeIdValidate("EM@1123");
				assertEquals(true,string);
	       }
	       @Test
			public  void roleIdValidate() throws InvalidDetailsException {
				boolean string=employeeDetailsValidation.isRoleIdValidate("RT_1001");
				assertEquals(true,string);
}
	       @Test(expected = InvalidDetailsException.class)
			public  void roleIdEmptyValidate() throws InvalidDetailsException {
				boolean string=employeeDetailsValidation.isRoleIdValidate("");
				assertEquals(true,string);
	       }
	       @Test(expected = InvalidDetailsException.class)
			public  void roleIdSpecialCharacterValidate() throws InvalidDetailsException {
				boolean string=employeeDetailsValidation.isRoleIdValidate("RT@1123");
				assertEquals(true,string);
	       
	}
	}
